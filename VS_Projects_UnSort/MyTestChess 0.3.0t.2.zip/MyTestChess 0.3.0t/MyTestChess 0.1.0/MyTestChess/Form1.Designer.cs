﻿namespace MyTestChess
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BP1 = new System.Windows.Forms.Label();
            this.BP2 = new System.Windows.Forms.Label();
            this.BP0 = new System.Windows.Forms.Label();
            this.BSlon1 = new System.Windows.Forms.Label();
            this.BKon1 = new System.Windows.Forms.Label();
            this.BLadia1 = new System.Windows.Forms.Label();
            this.BP7 = new System.Windows.Forms.Label();
            this.BP6 = new System.Windows.Forms.Label();
            this.BP5 = new System.Windows.Forms.Label();
            this.BP4 = new System.Windows.Forms.Label();
            this.BP3 = new System.Windows.Forms.Label();
            this.BSlon2 = new System.Windows.Forms.Label();
            this.BLedi = new System.Windows.Forms.Label();
            this.BKorol = new System.Windows.Forms.Label();
            this.BLadia2 = new System.Windows.Forms.Label();
            this.BKon2 = new System.Windows.Forms.Label();
            this.CP5 = new System.Windows.Forms.Label();
            this.CP4 = new System.Windows.Forms.Label();
            this.CP3 = new System.Windows.Forms.Label();
            this.CP2 = new System.Windows.Forms.Label();
            this.CP1 = new System.Windows.Forms.Label();
            this.CLadia1 = new System.Windows.Forms.Label();
            this.CP0 = new System.Windows.Forms.Label();
            this.CP7 = new System.Windows.Forms.Label();
            this.CP6 = new System.Windows.Forms.Label();
            this.CLadia2 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.CKon2 = new System.Windows.Forms.Label();
            this.CSlon2 = new System.Windows.Forms.Label();
            this.CLedi = new System.Windows.Forms.Label();
            this.CKorol = new System.Windows.Forms.Label();
            this.CSlon1 = new System.Windows.Forms.Label();
            this.CKon1 = new System.Windows.Forms.Label();
            this.Menu = new System.Windows.Forms.Button();
            this.Replay = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // BP1
            // 
            this.BP1.BackColor = System.Drawing.Color.Transparent;
            this.BP1.Image = ((System.Drawing.Image)(resources.GetObject("BP1.Image")));
            this.BP1.Location = new System.Drawing.Point(85, 214);
            this.BP1.Name = "BP1";
            this.BP1.Size = new System.Drawing.Size(73, 73);
            this.BP1.TabIndex = 8;
            this.BP1.Click += new System.EventHandler(this.BP1_Click);
            // 
            // BP2
            // 
            this.BP2.BackColor = System.Drawing.Color.Transparent;
            this.BP2.ForeColor = System.Drawing.Color.Transparent;
            this.BP2.Image = ((System.Drawing.Image)(resources.GetObject("BP2.Image")));
            this.BP2.Location = new System.Drawing.Point(159, 214);
            this.BP2.Name = "BP2";
            this.BP2.Size = new System.Drawing.Size(73, 73);
            this.BP2.TabIndex = 9;
            this.BP2.Click += new System.EventHandler(this.BP2_Click);
            // 
            // BP0
            // 
            this.BP0.BackColor = System.Drawing.Color.Transparent;
            this.BP0.Image = ((System.Drawing.Image)(resources.GetObject("BP0.Image")));
            this.BP0.Location = new System.Drawing.Point(43, 214);
            this.BP0.Name = "BP0";
            this.BP0.Size = new System.Drawing.Size(73, 73);
            this.BP0.TabIndex = 10;
            this.BP0.Click += new System.EventHandler(this.BP0_Click);
            // 
            // BSlon1
            // 
            this.BSlon1.BackColor = System.Drawing.Color.Transparent;
            this.BSlon1.Image = ((System.Drawing.Image)(resources.GetObject("BSlon1.Image")));
            this.BSlon1.Location = new System.Drawing.Point(85, 140);
            this.BSlon1.Name = "BSlon1";
            this.BSlon1.Size = new System.Drawing.Size(73, 73);
            this.BSlon1.TabIndex = 11;
            this.BSlon1.Click += new System.EventHandler(this.BSlon1_Click);
            // 
            // BKon1
            // 
            this.BKon1.BackColor = System.Drawing.Color.Transparent;
            this.BKon1.Image = ((System.Drawing.Image)(resources.GetObject("BKon1.Image")));
            this.BKon1.Location = new System.Drawing.Point(14, 77);
            this.BKon1.Name = "BKon1";
            this.BKon1.Size = new System.Drawing.Size(73, 73);
            this.BKon1.TabIndex = 12;
            this.BKon1.Click += new System.EventHandler(this.BKon1_Click);
            // 
            // BLadia1
            // 
            this.BLadia1.BackColor = System.Drawing.Color.Transparent;
            this.BLadia1.Image = ((System.Drawing.Image)(resources.GetObject("BLadia1.Image")));
            this.BLadia1.Location = new System.Drawing.Point(261, 36);
            this.BLadia1.Name = "BLadia1";
            this.BLadia1.Size = new System.Drawing.Size(73, 73);
            this.BLadia1.TabIndex = 13;
            this.BLadia1.Click += new System.EventHandler(this.BLadia1_Click);
            // 
            // BP7
            // 
            this.BP7.BackColor = System.Drawing.Color.Transparent;
            this.BP7.Image = ((System.Drawing.Image)(resources.GetObject("BP7.Image")));
            this.BP7.Location = new System.Drawing.Point(529, 214);
            this.BP7.Name = "BP7";
            this.BP7.Size = new System.Drawing.Size(73, 73);
            this.BP7.TabIndex = 14;
            this.BP7.Click += new System.EventHandler(this.BP7_Click);
            // 
            // BP6
            // 
            this.BP6.BackColor = System.Drawing.Color.Transparent;
            this.BP6.Image = ((System.Drawing.Image)(resources.GetObject("BP6.Image")));
            this.BP6.Location = new System.Drawing.Point(455, 214);
            this.BP6.Name = "BP6";
            this.BP6.Size = new System.Drawing.Size(73, 73);
            this.BP6.TabIndex = 15;
            this.BP6.Click += new System.EventHandler(this.BP6_Click);
            // 
            // BP5
            // 
            this.BP5.BackColor = System.Drawing.Color.Transparent;
            this.BP5.Image = ((System.Drawing.Image)(resources.GetObject("BP5.Image")));
            this.BP5.Location = new System.Drawing.Point(381, 214);
            this.BP5.Name = "BP5";
            this.BP5.Size = new System.Drawing.Size(73, 73);
            this.BP5.TabIndex = 16;
            this.BP5.Click += new System.EventHandler(this.BP5_Click);
            // 
            // BP4
            // 
            this.BP4.BackColor = System.Drawing.Color.Transparent;
            this.BP4.Image = ((System.Drawing.Image)(resources.GetObject("BP4.Image")));
            this.BP4.Location = new System.Drawing.Point(307, 214);
            this.BP4.Name = "BP4";
            this.BP4.Size = new System.Drawing.Size(73, 73);
            this.BP4.TabIndex = 17;
            this.BP4.Click += new System.EventHandler(this.BP4_Click);
            // 
            // BP3
            // 
            this.BP3.BackColor = System.Drawing.Color.Transparent;
            this.BP3.Image = ((System.Drawing.Image)(resources.GetObject("BP3.Image")));
            this.BP3.Location = new System.Drawing.Point(233, 214);
            this.BP3.Name = "BP3";
            this.BP3.Size = new System.Drawing.Size(73, 73);
            this.BP3.TabIndex = 18;
            this.BP3.Click += new System.EventHandler(this.BP3_Click);
            // 
            // BSlon2
            // 
            this.BSlon2.BackColor = System.Drawing.Color.Transparent;
            this.BSlon2.Image = ((System.Drawing.Image)(resources.GetObject("BSlon2.Image")));
            this.BSlon2.Location = new System.Drawing.Point(381, 140);
            this.BSlon2.Name = "BSlon2";
            this.BSlon2.Size = new System.Drawing.Size(73, 73);
            this.BSlon2.TabIndex = 19;
            this.BSlon2.Click += new System.EventHandler(this.BSlon2_Click);
            // 
            // BLedi
            // 
            this.BLedi.BackColor = System.Drawing.Color.Transparent;
            this.BLedi.Image = ((System.Drawing.Image)(resources.GetObject("BLedi.Image")));
            this.BLedi.Location = new System.Drawing.Point(307, 140);
            this.BLedi.Name = "BLedi";
            this.BLedi.Size = new System.Drawing.Size(73, 73);
            this.BLedi.TabIndex = 20;
            this.BLedi.Click += new System.EventHandler(this.BLedi_Click);
            // 
            // BKorol
            // 
            this.BKorol.BackColor = System.Drawing.Color.Transparent;
            this.BKorol.Image = ((System.Drawing.Image)(resources.GetObject("BKorol.Image")));
            this.BKorol.Location = new System.Drawing.Point(179, 141);
            this.BKorol.Name = "BKorol";
            this.BKorol.Size = new System.Drawing.Size(73, 73);
            this.BKorol.TabIndex = 21;
            this.BKorol.Click += new System.EventHandler(this.BKorol_Click);
            // 
            // BLadia2
            // 
            this.BLadia2.BackColor = System.Drawing.Color.Transparent;
            this.BLadia2.Image = ((System.Drawing.Image)(resources.GetObject("BLadia2.Image")));
            this.BLadia2.Location = new System.Drawing.Point(529, 140);
            this.BLadia2.Name = "BLadia2";
            this.BLadia2.Size = new System.Drawing.Size(73, 73);
            this.BLadia2.TabIndex = 22;
            this.BLadia2.Click += new System.EventHandler(this.BLadia2_Click);
            // 
            // BKon2
            // 
            this.BKon2.BackColor = System.Drawing.Color.Transparent;
            this.BKon2.Image = ((System.Drawing.Image)(resources.GetObject("BKon2.Image")));
            this.BKon2.Location = new System.Drawing.Point(455, 140);
            this.BKon2.Name = "BKon2";
            this.BKon2.Size = new System.Drawing.Size(73, 73);
            this.BKon2.TabIndex = 23;
            this.BKon2.Click += new System.EventHandler(this.BKon2_Click);
            // 
            // CP5
            // 
            this.CP5.BackColor = System.Drawing.Color.Transparent;
            this.CP5.Image = ((System.Drawing.Image)(resources.GetObject("CP5.Image")));
            this.CP5.Location = new System.Drawing.Point(426, 258);
            this.CP5.Name = "CP5";
            this.CP5.Size = new System.Drawing.Size(73, 73);
            this.CP5.TabIndex = 24;
            this.CP5.Click += new System.EventHandler(this.CP5_Click);
            // 
            // CP4
            // 
            this.CP4.BackColor = System.Drawing.Color.Transparent;
            this.CP4.Image = ((System.Drawing.Image)(resources.GetObject("CP4.Image")));
            this.CP4.Location = new System.Drawing.Point(352, 258);
            this.CP4.Name = "CP4";
            this.CP4.Size = new System.Drawing.Size(73, 73);
            this.CP4.TabIndex = 25;
            this.CP4.Click += new System.EventHandler(this.CP4_Click);
            // 
            // CP3
            // 
            this.CP3.BackColor = System.Drawing.Color.Transparent;
            this.CP3.Image = ((System.Drawing.Image)(resources.GetObject("CP3.Image")));
            this.CP3.Location = new System.Drawing.Point(278, 258);
            this.CP3.Name = "CP3";
            this.CP3.Size = new System.Drawing.Size(73, 73);
            this.CP3.TabIndex = 26;
            this.CP3.Click += new System.EventHandler(this.CP3_Click);
            // 
            // CP2
            // 
            this.CP2.BackColor = System.Drawing.Color.Transparent;
            this.CP2.Image = ((System.Drawing.Image)(resources.GetObject("CP2.Image")));
            this.CP2.Location = new System.Drawing.Point(204, 258);
            this.CP2.Name = "CP2";
            this.CP2.Size = new System.Drawing.Size(73, 73);
            this.CP2.TabIndex = 27;
            this.CP2.Click += new System.EventHandler(this.CP2_Click);
            // 
            // CP1
            // 
            this.CP1.BackColor = System.Drawing.Color.Transparent;
            this.CP1.Image = ((System.Drawing.Image)(resources.GetObject("CP1.Image")));
            this.CP1.Location = new System.Drawing.Point(130, 258);
            this.CP1.Name = "CP1";
            this.CP1.Size = new System.Drawing.Size(73, 73);
            this.CP1.TabIndex = 28;
            this.CP1.Click += new System.EventHandler(this.CP1_Click);
            // 
            // CLadia1
            // 
            this.CLadia1.BackColor = System.Drawing.Color.Transparent;
            this.CLadia1.Image = ((System.Drawing.Image)(resources.GetObject("CLadia1.Image")));
            this.CLadia1.Location = new System.Drawing.Point(56, 332);
            this.CLadia1.Name = "CLadia1";
            this.CLadia1.Size = new System.Drawing.Size(73, 73);
            this.CLadia1.TabIndex = 29;
            this.CLadia1.Click += new System.EventHandler(this.CLadia1_Click);
            // 
            // CP0
            // 
            this.CP0.BackColor = System.Drawing.Color.Transparent;
            this.CP0.Image = ((System.Drawing.Image)(resources.GetObject("CP0.Image")));
            this.CP0.Location = new System.Drawing.Point(56, 258);
            this.CP0.Name = "CP0";
            this.CP0.Size = new System.Drawing.Size(73, 73);
            this.CP0.TabIndex = 30;
            this.CP0.Click += new System.EventHandler(this.CP0_Click);
            // 
            // CP7
            // 
            this.CP7.BackColor = System.Drawing.Color.Transparent;
            this.CP7.Image = ((System.Drawing.Image)(resources.GetObject("CP7.Image")));
            this.CP7.Location = new System.Drawing.Point(574, 258);
            this.CP7.Name = "CP7";
            this.CP7.Size = new System.Drawing.Size(73, 73);
            this.CP7.TabIndex = 31;
            this.CP7.Click += new System.EventHandler(this.CP7_Click);
            // 
            // CP6
            // 
            this.CP6.BackColor = System.Drawing.Color.Transparent;
            this.CP6.Image = ((System.Drawing.Image)(resources.GetObject("CP6.Image")));
            this.CP6.Location = new System.Drawing.Point(500, 258);
            this.CP6.Name = "CP6";
            this.CP6.Size = new System.Drawing.Size(73, 73);
            this.CP6.TabIndex = 32;
            this.CP6.Click += new System.EventHandler(this.CP6_Click);
            // 
            // CLadia2
            // 
            this.CLadia2.BackColor = System.Drawing.Color.Transparent;
            this.CLadia2.Image = ((System.Drawing.Image)(resources.GetObject("CLadia2.Image")));
            this.CLadia2.Location = new System.Drawing.Point(574, 346);
            this.CLadia2.Name = "CLadia2";
            this.CLadia2.Size = new System.Drawing.Size(73, 73);
            this.CLadia2.TabIndex = 33;
            this.CLadia2.Click += new System.EventHandler(this.CLadia2_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(83, 72);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 35;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Visible = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // CKon2
            // 
            this.CKon2.BackColor = System.Drawing.Color.Transparent;
            this.CKon2.Image = ((System.Drawing.Image)(resources.GetObject("CKon2.Image")));
            this.CKon2.Location = new System.Drawing.Point(500, 332);
            this.CKon2.Name = "CKon2";
            this.CKon2.Size = new System.Drawing.Size(73, 73);
            this.CKon2.TabIndex = 36;
            this.CKon2.Click += new System.EventHandler(this.CKon2_Click);
            // 
            // CSlon2
            // 
            this.CSlon2.BackColor = System.Drawing.Color.Transparent;
            this.CSlon2.Image = ((System.Drawing.Image)(resources.GetObject("CSlon2.Image")));
            this.CSlon2.Location = new System.Drawing.Point(431, 332);
            this.CSlon2.Name = "CSlon2";
            this.CSlon2.Size = new System.Drawing.Size(73, 73);
            this.CSlon2.TabIndex = 37;
            this.CSlon2.Click += new System.EventHandler(this.CSlon2_Click);
            // 
            // CLedi
            // 
            this.CLedi.BackColor = System.Drawing.Color.Transparent;
            this.CLedi.Image = ((System.Drawing.Image)(resources.GetObject("CLedi.Image")));
            this.CLedi.Location = new System.Drawing.Point(352, 332);
            this.CLedi.Name = "CLedi";
            this.CLedi.Size = new System.Drawing.Size(73, 73);
            this.CLedi.TabIndex = 38;
            this.CLedi.Click += new System.EventHandler(this.CLedi_Click);
            // 
            // CKorol
            // 
            this.CKorol.BackColor = System.Drawing.Color.Transparent;
            this.CKorol.Image = ((System.Drawing.Image)(resources.GetObject("CKorol.Image")));
            this.CKorol.Location = new System.Drawing.Point(281, 346);
            this.CKorol.Name = "CKorol";
            this.CKorol.Size = new System.Drawing.Size(73, 73);
            this.CKorol.TabIndex = 39;
            this.CKorol.Click += new System.EventHandler(this.CKorol_Click);
            // 
            // CSlon1
            // 
            this.CSlon1.BackColor = System.Drawing.Color.Transparent;
            this.CSlon1.Image = ((System.Drawing.Image)(resources.GetObject("CSlon1.Image")));
            this.CSlon1.Location = new System.Drawing.Point(209, 332);
            this.CSlon1.Name = "CSlon1";
            this.CSlon1.Size = new System.Drawing.Size(73, 73);
            this.CSlon1.TabIndex = 40;
            this.CSlon1.Click += new System.EventHandler(this.CSlon1_Click);
            // 
            // CKon1
            // 
            this.CKon1.BackColor = System.Drawing.Color.Transparent;
            this.CKon1.Image = ((System.Drawing.Image)(resources.GetObject("CKon1.Image")));
            this.CKon1.Location = new System.Drawing.Point(130, 332);
            this.CKon1.Name = "CKon1";
            this.CKon1.Size = new System.Drawing.Size(73, 73);
            this.CKon1.TabIndex = 41;
            this.CKon1.Click += new System.EventHandler(this.CKon1_Click);
            // 
            // Menu
            // 
            this.Menu.Location = new System.Drawing.Point(70, 12);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(75, 23);
            this.Menu.TabIndex = 42;
            this.Menu.Text = "Меню";
            this.Menu.UseVisualStyleBackColor = true;
            this.Menu.Click += new System.EventHandler(this.Menu_Click);
            // 
            // Replay
            // 
            this.Replay.Location = new System.Drawing.Point(177, 36);
            this.Replay.Name = "Replay";
            this.Replay.Size = new System.Drawing.Size(75, 23);
            this.Replay.TabIndex = 43;
            this.Replay.Text = "Заново";
            this.Replay.UseVisualStyleBackColor = true;
            this.Replay.Visible = false;
            this.Replay.Click += new System.EventHandler(this.Replay_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1366, 768);
            this.Controls.Add(this.Replay);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.CKon1);
            this.Controls.Add(this.CSlon1);
            this.Controls.Add(this.CKorol);
            this.Controls.Add(this.CLedi);
            this.Controls.Add(this.CSlon2);
            this.Controls.Add(this.CKon2);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.CLadia2);
            this.Controls.Add(this.CP6);
            this.Controls.Add(this.CP7);
            this.Controls.Add(this.CP0);
            this.Controls.Add(this.CLadia1);
            this.Controls.Add(this.CP1);
            this.Controls.Add(this.CP2);
            this.Controls.Add(this.CP3);
            this.Controls.Add(this.CP4);
            this.Controls.Add(this.CP5);
            this.Controls.Add(this.BKon2);
            this.Controls.Add(this.BLadia2);
            this.Controls.Add(this.BKorol);
            this.Controls.Add(this.BLedi);
            this.Controls.Add(this.BSlon2);
            this.Controls.Add(this.BP3);
            this.Controls.Add(this.BP4);
            this.Controls.Add(this.BP5);
            this.Controls.Add(this.BP6);
            this.Controls.Add(this.BP7);
            this.Controls.Add(this.BLadia1);
            this.Controls.Add(this.BKon1);
            this.Controls.Add(this.BSlon1);
            this.Controls.Add(this.BP0);
            this.Controls.Add(this.BP2);
            this.Controls.Add(this.BP1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.M_Click);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label BP1;
        private System.Windows.Forms.Label BP2;
        private System.Windows.Forms.Label BP0;
        private System.Windows.Forms.Label BSlon1;
        private System.Windows.Forms.Label BKon1;
        private System.Windows.Forms.Label BLadia1;
        private System.Windows.Forms.Label BP7;
        private System.Windows.Forms.Label BP6;
        private System.Windows.Forms.Label BP5;
        private System.Windows.Forms.Label BP4;
        private System.Windows.Forms.Label BP3;
        private System.Windows.Forms.Label BSlon2;
        private System.Windows.Forms.Label BLedi;
        private System.Windows.Forms.Label BKorol;
        private System.Windows.Forms.Label BLadia2;
        private System.Windows.Forms.Label BKon2;
        private System.Windows.Forms.Label CP5;
        private System.Windows.Forms.Label CP4;
        private System.Windows.Forms.Label CP3;
        private System.Windows.Forms.Label CP2;
        private System.Windows.Forms.Label CP1;
        private System.Windows.Forms.Label CLadia1;
        private System.Windows.Forms.Label CP0;
        private System.Windows.Forms.Label CP7;
        private System.Windows.Forms.Label CP6;
        private System.Windows.Forms.Label CLadia2;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label CKon2;
        private System.Windows.Forms.Label CSlon2;
        private System.Windows.Forms.Label CLedi;
        private System.Windows.Forms.Label CKorol;
        private System.Windows.Forms.Label CSlon1;
        private System.Windows.Forms.Label CKon1;
        private System.Windows.Forms.Button Menu;
        private System.Windows.Forms.Button Replay;
        private System.Windows.Forms.Timer timer1;




    }
}

